cat /private/var/stash/share*/firmware/multitouch/iPhone.mtprops | grep -B2 0x0049 | grep data | sed 's/^\t\t<data>//' | sed 's/<\/data>$//' | base64 -d > zephyr2.bin
mv /tmp/i.txt /private/var/i
mv /tmp/d.txt /private/var/d
