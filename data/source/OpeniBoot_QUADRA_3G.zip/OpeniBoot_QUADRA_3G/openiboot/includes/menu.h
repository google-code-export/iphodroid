#ifndef MENU_H
#define MENU_H

#include "openiboot.h"

int menu_setup(int timeout);

#endif
