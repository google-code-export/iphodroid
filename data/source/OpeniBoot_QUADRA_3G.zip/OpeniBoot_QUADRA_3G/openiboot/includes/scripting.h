#ifndef SCRIPTING_H
#define SCRIPTING_H

#include "openiboot.h"

void startScripting();

//static void processCommand(char*);

#endif
