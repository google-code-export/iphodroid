#ifndef MIU_H
#define MIU_H

#include "openiboot.h"

int miu_setup();

#endif
