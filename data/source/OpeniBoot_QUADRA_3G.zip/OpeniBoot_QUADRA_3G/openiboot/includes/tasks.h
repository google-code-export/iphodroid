#ifndef TASKS_H
#define TASKS_H

#include "openiboot.h"

int tasks_setup();

#endif
