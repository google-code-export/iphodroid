#ifndef ARM_H
#define ARM_H

#include "openiboot.h"

int arm_setup();
void arm_disable_caches();

#endif
