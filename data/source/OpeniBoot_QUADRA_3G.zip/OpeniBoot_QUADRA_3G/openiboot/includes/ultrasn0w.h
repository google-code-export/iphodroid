#ifndef ULTRASNOW_H

int ultrasn0w();

#endif
