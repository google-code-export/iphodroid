#ifndef ACCEL_H
#define ACCEL_H

#include "openiboot.h"

int accel_setup();

int accel_get_x();
int accel_get_y();
int accel_get_z();

#endif
