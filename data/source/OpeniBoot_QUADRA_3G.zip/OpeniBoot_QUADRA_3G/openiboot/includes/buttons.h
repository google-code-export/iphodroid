#ifndef BUTTONS_H
#define BUTTONS_H

#include "openiboot.h"
#include "hardware/buttons.h"

int buttons_is_pushed(int);

#endif
