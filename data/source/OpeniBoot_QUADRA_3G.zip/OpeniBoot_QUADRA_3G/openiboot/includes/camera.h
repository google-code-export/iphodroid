#ifndef CAMERA_H
#define CAMERA_H

int camera_setup();

#endif
